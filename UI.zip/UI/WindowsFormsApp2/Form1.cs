﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Timers;

namespace WindowsFormsApp2
{


    public partial class Form1 : Form
    {
        char[] dataChars = new char[8];
        int[] data = new int[8];
        string dataS;
        string[] names = new string[4] { "KCody", "JPrice", "JTulio", "JTorres" }; // user names
        bool ValidUser=false;
        Encoding enc = Encoding.GetEncoding(1252); // Encoding needed for data transfer
        double panelV;
        double invertV;
        double chargeV;
        double USBV;

        double panelC;
        double invertC;
        double chargeC;
        double USBC;

        public Form1()
        {
            InitializeComponent();
            
        }

        
        
        // Panel Data
        private void button1_Click(object sender, EventArgs e)
        {
            if (label9.BackColor != Color.Red)
            {
                resetColor();
                label9.BackColor = Color.Green;
            }
            
            this.label1.Text = "System";
            this.label2.Text = "Voltage";
            this.label3.Text = "Current";
            this.label4.Text = "Capability";
            this.label5.Text = "Panel";

            getData();
            this.label19.Text = panelV.ToString();
            this.label7.Text = panelC.ToString();
            double eff=panelV/21.7;
            this.label8.Text = eff.ToString();


        }

        // USB Port Data
        private void button2_Click(object sender, EventArgs e)
        {
            if (label13.BackColor != Color.Red)
            {
                resetColor();
                label13.BackColor = Color.Green;
            }
            
            this.label1.Text = "System";
            this.label2.Text = "Voltage";
            this.label3.Text = "Current";
            this.label4.Text = "Power";
            this.label5.Text = "USB Ports";

            getData();
            this.label19.Text = USBV.ToString();
            this.label7.Text = USBC.ToString();
            double P = USBC * USBV;
            this.label8.Text = P.ToString();
        }


        // Inverter Data
        private void button3_Click(object sender, EventArgs e)
        {

            if (label14.BackColor != Color.Red)
            {
                resetColor();
                label14.BackColor = Color.Green;
            }
           
            this.label1.Text = "System";
            this.label2.Text = "Voltage";
            this.label3.Text = "Current";
            this.label4.Text = "Power";
            this.label5.Text = "Inverter";

            getData();
            this.label19.Text = invertV.ToString();
            this.label7.Text = invertC.ToString();
            double P = invertV * invertC;
            this.label8.Text =P.ToString();
        }


        // Charge Controller Data
        private void button4_Click(object sender, EventArgs e)
        {


            if (label12.BackColor != Color.Red)
            {
                resetColor();
                label12.BackColor = Color.Green;
            }

            this.label1.Text = "System";
            this.label2.Text = "Voltage";
            this.label3.Text = "Current";
            this.label4.Text = "Power";
            this.label5.Text = "Charge Controller";

            getData();
            this.label19.Text = chargeV.ToString();
            this.label7.Text = chargeC.ToString();
            double P = chargeV * chargeC;
            this.label8.Text = P.ToString();

        }


       // Reset Button Disabled Due to Hardware Limitations
        private void button7_Click(object sender, EventArgs e)
        {

            /*
            serialPort1.Open();
            serialPort1.WriteLine("1");
            serialPort1.Close();
            */
            this.label1.Text = "System";
            this.label2.Text = "";
            this.label3.Text = "";
            this.label4.Text = "";

            this.label5.Text = "Stopped";

            
            label9.BackColor = Color.Red;
            label10.BackColor = Color.Red;
            label11.BackColor = Color.Red;
            label12.BackColor = Color.Red;
            label13.BackColor = Color.Red;
            label14.BackColor = Color.Red;
        }

        // System Reset
        private void button9_Click(object sender, EventArgs e)
        {
            serialPort1.Open();
            serialPort1.WriteLine("6");
            serialPort1.Close();
            
            label9.BackColor = Color.Transparent;
            label10.BackColor = Color.Transparent;
            label11.BackColor = Color.Transparent;
            label12.BackColor = Color.Transparent;
            label13.BackColor = Color.Transparent;
            label14.BackColor = Color.Transparent;

            checkBox3.Enabled = !checkBox3.Enabled;
            checkBox5.Enabled = !checkBox5.Enabled;
            checkBox6.Enabled = !checkBox6.Enabled;
            checkBox1.Enabled = !checkBox1.Enabled;

            this.label1.Text = "System";
            this.label2.Text = "Panel V.";
            this.label3.Text = "USB V.";
            this.label4.Text = "Chearge V.";

            this.label5.Text = "Overview";

            getData();
            this.label19.Text = panelV.ToString();
            this.label7.Text = USBV.ToString();
            this.label8.Text = chargeV.ToString();
        }


        // System Overview
        private void button8_Click(object sender, EventArgs e)
        {

            this.label1.Text = "System";
            this.label2.Text = "Panel V.";
            this.label3.Text = "USB V.";
            this.label4.Text = "Charge V.";

            this.label5.Text = "Overview";

           getData();
            this.label19.Text = panelV.ToString();
            this.label7.Text = USBV.ToString();
            this.label8.Text = chargeV.ToString();

        }



        // Data Transfer Request
        private void getData()
        {
            serialPort1.Open();
            serialPort1.WriteLine("0");
            timer1.Start();
            serialPort1.Encoding = enc;
            for (int i = 0; i < 8; i++)
            {
                int j = serialPort1.ReadChar();
                data[i] = j;
                timer1.Start();
            }

            double a = data[0];
            double b = data[1]; 
            double c = data[2];
            double d = data[3];

            double e = data[4];
            double f = data[5]; 
            double g = data[6]; 
            double h = data[7];

            // Calculate Voltages
            panelV=32.1*(a/255);
            invertV=15.3*(b/255);
            USBV = 4*5.78 * (c / 255);
            chargeV =15.3*(d/255);
            
            // Calculate Currents (See current sensor excel file)
            panelC = 3.3 * (e / 255);
            panelC = (2*panelC - 2.4844) / 0.1337;

            chargeC =  (h / 255);
            chargeC = (2 * chargeC - 2.4844) / 0.1337;

            USBC = 3.3 * (g / 255);
            USBC = (4*USBC - 2.4844) / 0.1337;

            invertC = 3.3 * (f / 255);
            invertC = (2 * invertC - 2.4844) / 0.1337;

            


            serialPort1.Close();


        }

        // Resets color every new button press
        private void resetColor()
        {
            if (label9.BackColor != Color.Red)
                label9.BackColor = Color.Transparent;

            if (label10.BackColor != Color.Red)
                label10.BackColor = Color.Transparent;

            if (label11.BackColor != Color.Red)
                label11.BackColor = Color.Transparent;

            if (label12.BackColor != Color.Red)
                label12.BackColor = Color.Transparent;

            if (label13.BackColor != Color.Red)
                label13.BackColor = Color.Transparent;

            if (label14.BackColor != Color.Red)
                label14.BackColor = Color.Transparent;

        }

        // Disable Solar Panal
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {


            if (label9.BackColor == Color.Red)
                label9.BackColor = Color.Transparent;
            else
                label9.BackColor = Color.Red;

            
                checkBox3.Enabled = !checkBox3.Enabled;
                checkBox5.Enabled = !checkBox5.Enabled;
                checkBox6.Enabled = !checkBox6.Enabled;
                checkBox1.Enabled = !checkBox1.Enabled;

            MessageBox.Show("Press System Reset to Reenable Component", "", MessageBoxButtons.OK);
            
            serialPort1.Open();
            serialPort1.WriteLine("2");
            serialPort1.Close();
            
        }

        // Disable USB Ports
        private void checkBox3_CheckedChanged_1(object sender, EventArgs e)
        {
        
            if (label12.BackColor == Color.Red)
                label12.BackColor = Color.Transparent;
            else
                label12.BackColor = Color.Red;

            checkBox1.Enabled = !checkBox1.Enabled;
            checkBox5.Enabled = !checkBox5.Enabled;
            checkBox6.Enabled = !checkBox6.Enabled;
            checkBox3.Enabled = !checkBox3.Enabled;

            MessageBox.Show("Press System Reset to Reenable Component", "", MessageBoxButtons.OK);

            serialPort1.Open();
           serialPort1.WriteLine("3");
           serialPort1.Close();
           
        }

        // Disable Charge Controller
        private void checkBox5_CheckedChanged_1(object sender, EventArgs e)
        {
           

            if (label13.BackColor == Color.Red)
                label13.BackColor = Color.Transparent;
            else
                label13.BackColor = Color.Red;

            checkBox3.Enabled = !checkBox3.Enabled;
            checkBox1.Enabled = !checkBox1.Enabled;
            checkBox6.Enabled = !checkBox6.Enabled;
            checkBox5.Enabled = !checkBox5.Enabled;

            checkBox3.Checked = false;
            checkBox1.Checked = false;
            checkBox6.Checked = false;
            checkBox5.Checked = false;

            MessageBox.Show("Press System Reset to Reenable Component", "", MessageBoxButtons.OK);

            serialPort1.Open();
           serialPort1.WriteLine("4");
           serialPort1.Close();
           
        }

        //Disable Inverter
        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            

            if (label14.BackColor == Color.Red)
                label14.BackColor = Color.Transparent;
            else
                label14.BackColor = Color.Red;

            checkBox3.Enabled = !checkBox3.Enabled;
            checkBox5.Enabled = !checkBox5.Enabled;
            checkBox1.Enabled = !checkBox1.Enabled;
            checkBox6.Enabled = !checkBox6.Enabled;

            MessageBox.Show("Press System Reset to Reenable Component", "", MessageBoxButtons.OK);

            serialPort1.Open();
           serialPort1.WriteLine("5");
           serialPort1.Close();
           
        }



        // Closing security protections
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (ValidUser == false)
            {
                MessageBox.Show("Please Enter Valid Username and Password", "", MessageBoxButtons.OK);
                e.Cancel = true;
                return;
            }

            if (MessageBox.Show("Are you sure you want to close the form?", "Close Form",
               MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        // Login Button
        private void button5_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 4; i++)
            {
                if (textBox1.Text == names[i])
                {
                    if (textBox2.Text == "ECE3334")
                    {
                        checkBox1.Enabled = true;
                        checkBox3.Enabled = true;

                        checkBox5.Enabled = true;
                        checkBox6.Enabled = true;
                        textBox1.Enabled = false;
                        textBox2.Enabled = false;
                        MessageBox.Show("Please Logout when Finished", "", MessageBoxButtons.OK);
                        ValidUser = true;
                    }
                }
            }
        }

        // Logout Button
        private void button6_Click(object sender, EventArgs e)
        {
            checkBox1.Enabled = false;
            checkBox3.Enabled = false;

            checkBox5.Enabled = false;
            checkBox6.Enabled = false;
            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox1.Text = "";
            textBox2.Text = "";
            ValidUser = false;
            MessageBox.Show("You Have Been Logged Out", "", MessageBoxButtons.OK);
           
        }


    }



    
}

    
